"""Functional decomposition package."""
