"""Canonical BA model package."""
