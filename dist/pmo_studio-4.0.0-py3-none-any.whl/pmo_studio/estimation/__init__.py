"""Source-driven estimation helpers."""
